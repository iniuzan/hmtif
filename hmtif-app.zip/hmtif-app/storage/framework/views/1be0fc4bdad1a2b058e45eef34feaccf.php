<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
  <h3 class="text-xl">Selamat Datang di website HMTIF - UNPAS</h3>
  <img class="w-72 mx-auto p-5 drop-shadow-2xl hover:drop-shadow-none"  src="/image/LOGO HMTIF.png" alt="">
  <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae, nam? Dolor repellat eveniet reiciendis doloremque quas, mollitia expedita omnis dolores quos unde maiores molestiae facere tenetur officiis quae odio corrupti tempore libero, quasi ab a. Labore tempore praesentium magnam voluptatibus voluptas repellendus, ipsam maxime quidem minus sit deleniti quod at temporibus voluptates veniam tenetur incidunt? Totam veritatis ipsum corrupti laboriosam blanditiis consequatur, ipsa rerum? Sed voluptate magnam a adipisci accusantium natus saepe dicta facilis repellendus autem voluptas similique, dolorem temporibus. Ducimus dolorum enim hic saepe quas. Adipisci facilis, odio modi dolore quaerat provident ullam incidunt, nemo, velit aut numquam soluta doloribus. Quidem, consectetur! Earum deserunt molestiae reiciendis quod quaerat ullam, officia magni corporis exercitationem soluta aliquid ea tempora deleniti doloremque odio, impedit sapiente rem cum, esse dolorum error qui. Error nam ab maxime nostrum sequi beatae vel, accusantium eaque deleniti animi voluptate corporis nulla minus tenetur voluptatum ipsam aliquid ea quasi veniam distinctio quidem minima commodi doloremque? Accusantium nihil commodi et iusto nisi at deserunt doloribus, hic est quibusdam quaerat quasi sit quas suscipit voluptatem cum quisquam delectus, ipsa aliquid aspernatur dolore corporis labore laborum? Minus, possimus expedita tenetur aspernatur odio provident quae quis, facere assumenda magnam labore! Ea, nobis.</h2>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\Dev\Laravel\hmtif-app\resources\views/Home.blade.php ENDPATH**/ ?>