<x-layout>
  <x-slot:title>{{ $title }}</x-slot:title>
  <h3>Contact us here!</h3>
</x-layout>