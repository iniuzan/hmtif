<x-layout>
  <x-slot:title>{{ $title }}</x-slot:title>
  <h3>About us!</h3>
  <p>{{ $Author }}</p>
</x-layout>